//
//  PageOneView.swift
//  WWDC2023 App
//
//  Created by Dylan Juliano Santoso on 19/04/23.
//

import SwiftUI

struct AksaraJawaView: View {
    //Number of question
    @State var i: Int = 0
    
    //Variable for the score
    @State var score = 0
    
    @State private var showModal = false
    
    var body: some View {
            NavigationView {
                ZStack {
                    Color.white
                    VStack {
                        Spacer()
                        if(self.i < AksaraJawaQuiz.count) {
                            
                            //Aksara Jawa (Question)
                            Text(AksaraJawaQuiz[self.i].aksara!)
                                .font(.title)
                                .bold()
                                .foregroundColor(.black)
                                .padding()
                            
                            //Questions
                            Text(AksaraJawaQuiz[self.i].question!)
                                .foregroundColor(.black)
                                .padding([.leading, .bottom, .trailing])
                            
                            //First Answer
                            Button (action: {
                                self.buttonPressed(n: 0)
                                self.showModal = true
                            }, label: {
                                Text(AksaraJawaQuiz[self.i].answer[0])
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(uiColor: UIColor(named: "Tea Green")!))
                                    )
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray, lineWidth: 0.2)
                                    )
                                    .padding([.leading, .trailing])
                            })
                            .actionSheet(isPresented: $showModal) {
                                ActionSheet(
                                    title: Text("No need to hurry, just make sure you are convinced with your answer"),
                                    message: Text("Your Score is \(self.score) out of \(AksaraJawaQuiz.count)"),
                                    buttons: [
                                        .cancel {print(self.showModal)}
                                    ]
                                )
                            }
                            
                            //Second Answer
                            Button (action: {
                                self.buttonPressed(n: 1)
                                self.showModal = true
                            }, label: {
                                Text(AksaraJawaQuiz[self.i].answer[1])
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(uiColor: UIColor(named: "Celadon")!))
                                    )
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray, lineWidth: 0.2)
                                    )
                                    .padding([.leading, .trailing])
                            })
                            .actionSheet(isPresented: $showModal) {
                                ActionSheet(
                                    title: Text("No need to hurry, just make sure you are convinced with your answer"),
                                    message: Text("Your Score is \(self.score) out of \(AksaraJawaQuiz.count)"),
                                    buttons: [
                                        .cancel {print(self.showModal)}
                                    ]
                                )
                            }
                            
                            //Third Answer
                            Button (action: {
                                self.buttonPressed(n: 2)
                                self.showModal = true
                            }, label: {
                                Text(AksaraJawaQuiz[self.i].answer[2])
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(uiColor: UIColor(named: "Ash Gray")!))
                                    )
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray, lineWidth: 0.2)
                                    )
                                    .padding([.leading, .trailing])
                            })
                            .actionSheet(isPresented: $showModal) {
                                ActionSheet(
                                    title: Text("No need to hurry, just make sure you are convinced with your answer"),
                                    message: Text("Your Score is \(self.score) out of \(AksaraJawaQuiz.count)"),
                                    buttons: [
                                        .cancel {print(self.showModal)}
                                    ]
                                )
                            }
                            
                            //Forth Answer
                            Button (action: {
                                self.buttonPressed(n: 3)
                                self.showModal = true
                            }, label: {
                                Text(AksaraJawaQuiz[self.i].answer[3])
                                    .foregroundColor(.black)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color(uiColor: UIColor(named: "Cadet Gray")!))
                                    )
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray, lineWidth: 0.2)
                                    )
                                    .padding([.leading, .trailing])
                            })
                            .actionSheet(isPresented: $showModal) {
                                ActionSheet(
                                    title: Text("No need to hurry, just make sure you are convinced with your answer"),
                                    message: Text("Your Score is \(self.score) out of \(AksaraJawaQuiz.count)"),
                                    buttons: [
                                        .cancel {print(self.showModal)}
                                    ]
                                )
                            }
                            
                        } else {
                            CongratulationsView(score: self.score)
                        }
                        Spacer()
                    }
                }
            }
    }
    
    //n is the answer options
    func buttonPressed(n: Int) {
        
        //If user answer correctly, the score will be increased by 1
        if (AksaraJawaQuiz[self.i].correctAnswer == n) {
            self.score = self.score + 1
        }
        //Heading to the next question
        self.i = self.i + 1
    }
}

struct AksaraJawaView_Previews: PreviewProvider {
    static var previews: some View {
        AksaraJawaView()
    }
}
