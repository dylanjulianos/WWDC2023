import SwiftUI

@available(iOS 16.0, *)
struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.white
                VStack {
                    Text("Aksara Jawa")
                        .font(.title)
                        .bold()
                        .foregroundColor(.black)
                    
                    Text("꧋ꦄꦏ꧀ꦱꦫꦗꦮ")
                        .font(.title)
                        .foregroundColor(.black)
                    
                    Text("by Dylan Juliano Santoso WWDC2023")
                        .padding()
                        .font(.caption)
                        .foregroundColor(.black)
                    
                    NavigationLink(destination: MaterialView(), label: {
                        Text("Aksara Jawa")
                            .frame(width: 150, height: 40)
                            .background(Color.orange)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                    })
                    
                    NavigationLink(destination: ExampleView(), label: {
                        Text("Example")
                            .frame(width: 150, height: 40)
                            .background(Color.orange)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                    })
                    
                    NavigationLink(destination: AksaraJawaView(), label: {
                        Text("Start")
                            .frame(width: 150, height: 40)
                            .background(Color.orange)
                            .cornerRadius(8)
                            .foregroundColor(.white)
                    })
                }
            }
        }
    }
}
