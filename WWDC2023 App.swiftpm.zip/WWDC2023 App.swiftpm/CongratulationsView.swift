//
//  CongratulationsView.swift
//  WWDC2023 App
//
//  Created by Dylan Juliano Santoso on 19/04/23.
//

import SwiftUI

struct CongratulationsView: View {
    
    var score: Int
    
    var body: some View {
        ZStack {
            Color.white
            VStack {
                Image(uiImage: UIImage(named: "Yippie")!)
                    .resizable()
                    .frame(width: 150, height: 150)
                Text("WELL DONE!")
                    .bold()
                    .font(.title)
                
                Text("Thank you for your enthusiasm to learn one of many Indonesia Cultures! You already finish your Aksara Jawa course amazingly with the score \(score) out of \(AksaraJawaQuiz.count)🏆")
                    .multilineTextAlignment(.center)
                    .lineSpacing(8)
                    .padding([.leading, .trailing])
                    .font(.subheadline)
                    .onAppear() {
                        saveScore(quiz: "AksaraJawaQuiz", score: self.score)
                    }
            }
        }
    }
}

struct CongratulationsView_Previews: PreviewProvider {
    static var previews: some View {
        CongratulationsView(score: 1)
    }
}
