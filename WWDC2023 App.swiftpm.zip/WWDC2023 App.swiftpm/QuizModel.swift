//
//  QuizModel.swift
//  WWDC2023 App
//
//  Created by Dylan Juliano Santoso on 19/04/23.
//

import Foundation

struct QuizModel {
    var aksara: String?
    var question: String?
    var answer: [String]
    var correctAnswer: Int?
}

var AksaraJawaQuiz: [QuizModel] = [
    QuizModel(aksara: "꧋ꦭꦶꦱ", question: "What does Aksara Jawa above mean?", answer: ["Lisa", "Lasi", "Lala", "Lia"], correctAnswer: 0),
    QuizModel(aksara: "꧋ꦲꦤ", question: "What does Aksara Jawa above mean?", answer: ["Hini", "Hino", "Hana", "Hani"], correctAnswer: 2),
    QuizModel(aksara: "꧋ꦫꦺꦴꦱꦺ", question: "What does Aksara Jawa above mean?", answer: ["Risa", "Rasa", "Rosi", "Rose"], correctAnswer: 3),
    QuizModel(aksara: "꧋ꦗꦶꦱꦺꦴ", question: "What does Aksara Jawa above mean?", answer: ["Jasa", "Jiso", "Josi", "Jisa"], correctAnswer: 1),
    QuizModel(aksara: "꧋ꦥꦫꦶꦱ꧀", question: "What does Aksara Jawa above mean?", answer: ["Paris", "Paras", "Piris", "Piros"], correctAnswer: 0),
    QuizModel(aksara: "Miki", question: "What Aksara Jawa describe the word above?", answer: ["꧋ꦩꦏꦺꦴ", "꧋ꦩꦏ", "꧋ꦩꦶꦏꦶ", "꧋ꦩꦶꦏ"], correctAnswer: 2),
    QuizModel(aksara: "Latin", question: "What Aksara Jawa describe the word above?", answer: ["꧋ꦭꦭ", "꧋ꦭꦕꦶ", "꧋ꦭꦠꦺꦴ", "꧋ꦭꦠꦶꦤ꧀"], correctAnswer: 3),
    QuizModel(aksara: "Demi", question: "What Aksara Jawa describe the word above?", answer: ["꧋ꦣꦶꦩꦺ", "꧋ꦣꦼꦩꦶ", "꧋ꦣꦺꦴꦩꦶ", "꧋ꦣꦩ"], correctAnswer: 1)
]

func saveScore(quiz: String, score: Int) {
    UserDefaults.standard.set(score, forKey: quiz)
}
