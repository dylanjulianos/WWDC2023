//
//  PageTwoView.swift
//  WWDC2023 App
//
//  Created by Dylan Juliano Santoso on 19/04/23.
//

import SwiftUI

//@available(iOS 16.0, *)
struct MaterialView: View {
    var body: some View {
        ZStack {
            Color.white
            ScrollView {
                VStack {
                    Image(uiImage: UIImage(named: "Confused")!)
                        .resizable()
                        .frame(width: 150, height: 150)
                    
                    Text("So, What is Aksara Jawa?")
                        .bold()
                        .foregroundColor(.black)
                        .font(.title)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 5)
                    
                    Text("Aksara Jawa itself is a traditional Indonesian script (visual symbol system) that developed on the island of Java and it is often used to write Javanese and has developed, it is also used to write other languages ​​such as Sundanese, Madurese, Sasak, and Malay.")
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding([.leading, .bottom, .trailing])
                        
                        Image(uiImage: UIImage(named: "AksaraJawa")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 300)
                        
                        Text("Sandhangan Swara")
                            .font(.title2)
                            .foregroundColor(.black)
                            .bold()
                            .padding(.top)
                        
                        Image(uiImage: UIImage(named: "Sandhangan")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 300)
                        
                        Text("Pasangan Aksara Jawa")
                            .font(.title2)
                            .foregroundColor(.black)
                            .bold()
                            .padding(.top)
                        
                        Image(uiImage: UIImage(named: "Pasangan")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200)
                        Spacer()
                }
            }
        }
//        .scrollIndicators(.hidden)
    }
}

struct MaterialView_Previews: PreviewProvider {
    static var previews: some View {
        MaterialView()
    }
}
