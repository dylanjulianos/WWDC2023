//
//  ExampleView.swift
//  WWDC2023 App
//
//  Created by Dylan Juliano Santoso on 19/04/23.
//

import SwiftUI

struct ExampleView: View {
    var body: some View {
        ZStack {
            Color.white
            VStack(alignment: .leading) {
                Text("Example 💡")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.black)
                    .padding(.top)
                    .padding(.bottom)
                
                Text("Bali : ꧋ꦧꦭꦶ")
                    .bold()
                    .foregroundColor(.black)
                    .font(.title2)
                    .padding(.bottom, 5)
                
                Text("ꦧ = Ba\nꦭꦶ = Li (La + Sandhangan Swara Wulu (i))")
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.black)
                    .lineSpacing(10)
                    .padding(.bottom)
                
                Text("London : ꧋ꦭꦺꦴꦤ꧀ꦝꦺꦴꦤ꧀")
                    .bold()
                    .foregroundColor(.black)
                    .font(.title2)
                    .padding(.top)
                    .padding(.bottom, 5)
                
                Text("ꦭꦺꦴ = Lon (La + Sandhangan Swara Taling Tarung (o)\nꦣꦺꦴ = Don (Da + Sandhangan Swara Taling Tarung (o) + Na + Pangkon)")
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)
                    .lineSpacing(10)
                    .padding(.bottom)
                
                Text("Jakarta : ꧋ꦗꦏꦂꦠ")
                    .bold()
                    .foregroundColor(.black)
                    .font(.title2)
                    .padding(.top)
                    .padding(.bottom, 5)
                
                Text("ꦗ = Ja\nꦏꦂ = Kar (Ka + Sandhangan Swara Layar (r)\nꦠ = Ta")
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)
                    .lineSpacing(10)
                Spacer()
            }

        }
    }
}

struct ExampleView_Previews: PreviewProvider {
    static var previews: some View {
        ExampleView()
    }
}
